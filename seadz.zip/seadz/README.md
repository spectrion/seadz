# 🌊 Seadz

A self-hostable web crawler and archiver. Run it locally, manage crawls from a browser UI, browse your archive.

## Install

```bash
git clone https://github.com/YOUR_USERNAME/seadz
cd seadz
npm install
npm start
```

That's it. Your browser opens automatically at `http://localhost:3131`.

## Usage

1. Click **New crawl**
2. Paste a URL, set depth, hit **Create & start**
3. Watch it crawl live — pages appear in the **Archive** tab as they come in
4. Click any archived page to view a snapshot

## Options

| Env variable | Default | Description |
|---|---|---|
| `PORT` | `3131` | Local server port |
| `SEADZ_DELAY` | `1200` | Milliseconds between requests per domain |
| `SEADZ_MAX_PAGES` | `1000` | Max pages per crawl run |
| `SEADZ_DATA` | `./data` | Where the database lives |

```bash
SEADZ_DELAY=2000 SEADZ_MAX_PAGES=500 npm start
```

## Data

Everything is stored locally in `data/seadz.db` (SQLite). No cloud, no accounts, no telemetry.

## License

MIT
