// index.js — Express server + local UI launcher
import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import open from 'open';
import db, {
  getCrawls, getCrawl, createCrawl, updateCrawl, deleteCrawl,
  getPages, getPageCount, getPage, getLogs, globalStats, addLog
} from './db.js';
import { startCrawl, stopCrawl, isRunning } from './crawler.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = process.env.PORT || 3131;

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, '../public')));

// SSE clients per crawl id
const sseClients = new Map(); // crawlId → Set<res>

function broadcast(crawlId, data) {
  const clients = sseClients.get(crawlId);
  if (!clients) return;
  const msg = `data: ${JSON.stringify(data)}\n\n`;
  for (const res of clients) res.write(msg);
}

// ── Stats ─────────────────────────────────────────────────
app.get('/api/stats', (req, res) => {
  res.json(globalStats());
});

// ── Crawls ────────────────────────────────────────────────
app.get('/api/crawls', (req, res) => {
  res.json(getCrawls());
});

app.post('/api/crawls', (req, res) => {
  const { name, seed_url, depth, same_domain } = req.body;
  if (!seed_url) return res.status(400).json({ error: 'seed_url required' });
  try { new URL(seed_url); } catch { return res.status(400).json({ error: 'invalid URL' }); }
  const crawl = createCrawl({
    name: name || new URL(seed_url).hostname,
    seed_url,
    depth: depth ?? 2,
    same_domain: same_domain ?? 1,
  });
  res.json(crawl);
});

app.get('/api/crawls/:id', (req, res) => {
  const crawl = getCrawl(req.params.id);
  if (!crawl) return res.status(404).json({ error: 'not found' });
  res.json({ ...crawl, running: isRunning(crawl.id) });
});

app.delete('/api/crawls/:id', (req, res) => {
  stopCrawl(parseInt(req.params.id));
  deleteCrawl(req.params.id);
  res.json({ ok: true });
});

// ── Crawl control ─────────────────────────────────────────
app.post('/api/crawls/:id/start', (req, res) => {
  const id = parseInt(req.params.id);
  const crawl = getCrawl(id);
  if (!crawl) return res.status(404).json({ error: 'not found' });
  if (isRunning(id)) return res.status(409).json({ error: 'already running' });

  // Reset if previously done/stopped
  if (crawl.status !== 'idle') {
    // Start fresh counts but keep existing pages
    updateCrawl(id, { status: 'idle', pages_done: 0, pages_found: 0, started_at: null, finished_at: null });
  }

  startCrawl(id, (event) => broadcast(id, event));
  res.json({ ok: true });
});

app.post('/api/crawls/:id/stop', (req, res) => {
  stopCrawl(parseInt(req.params.id));
  res.json({ ok: true });
});

// ── SSE stream ────────────────────────────────────────────
app.get('/api/crawls/:id/stream', (req, res) => {
  const id = parseInt(req.params.id);
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders();

  if (!sseClients.has(id)) sseClients.set(id, new Set());
  sseClients.get(id).add(res);

  // Send current state immediately
  const crawl = getCrawl(id);
  if (crawl) res.write(`data: ${JSON.stringify({ type: 'init', crawl, running: isRunning(id) })}\n\n`);

  req.on('close', () => {
    sseClients.get(id)?.delete(res);
  });
});

// ── Logs ──────────────────────────────────────────────────
app.get('/api/crawls/:id/logs', (req, res) => {
  res.json(getLogs(req.params.id, 200));
});

// ── Pages ─────────────────────────────────────────────────
app.get('/api/pages', (req, res) => {
  const { crawl_id, search, limit = 100, offset = 0 } = req.query;
  const pages = getPages({ crawlId: crawl_id, search, limit: parseInt(limit), offset: parseInt(offset) });
  const total = getPageCount({ crawlId: crawl_id, search });
  res.json({ pages, total });
});

app.get('/api/pages/:id', (req, res) => {
  const page = getPage(req.params.id);
  if (!page) return res.status(404).json({ error: 'not found' });
  res.json(page);
});

// Serve snapshot HTML
app.get('/api/pages/:id/snapshot', (req, res) => {
  const page = getPage(req.params.id);
  if (!page || !page.snapshot) return res.status(404).send('No snapshot');
  res.setHeader('Content-Type', 'text/html; charset=utf-8');
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  // Inject base tag so relative links resolve
  const html = page.snapshot.replace('<head>', `<head><base href="${page.url}">`);
  res.send(html);
});

// ── SPA fallback ──────────────────────────────────────────
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../public/index.html'));
});

// ── Start ─────────────────────────────────────────────────
app.listen(PORT, () => {
  const url = `http://localhost:${PORT}`;
  console.log(`\n🌊 Seadz running at ${url}\n`);
  // Auto-open browser
  open(url).catch(() => {});
});
