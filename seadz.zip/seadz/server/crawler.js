// crawler.js — per-crawl crawl engine
import robotsParser from 'robots-parser';
import {
  getCrawl, updateCrawl, enqueueUrl, dequeueUrl,
  markUrlDone, markUrlFailed, hasSeenUrl, savePage,
  urlQueueStats, addLog
} from './db.js';

const USER_AGENT = 'Seadz/0.1 (+https://github.com/seadz/seadz)';
const DELAY_MS   = parseInt(process.env.SEADZ_DELAY || '1200');
const MAX_PAGES  = parseInt(process.env.SEADZ_MAX_PAGES || '1000');

const robotsCache  = new Map();
const domainTimers = new Map();

// Active crawl controllers keyed by crawl ID
const activeCrawls = new Map();

export function isRunning(crawlId) {
  return activeCrawls.has(crawlId);
}

export async function startCrawl(crawlId, onProgress) {
  if (activeCrawls.has(crawlId)) return;

  const abort = { cancelled: false };
  activeCrawls.set(crawlId, abort);

  const crawl = getCrawl(crawlId);
  if (!crawl) return;

  updateCrawl(crawlId, { status: 'running', started_at: new Date().toISOString() });
  addLog(crawlId, `Crawl started — seed: ${crawl.seed_url}`);
  onProgress?.({ type: 'status', status: 'running' });

  // Seed the queue
  enqueueUrl(crawlId, crawl.seed_url, 0, null);
  updateCrawl(crawlId, { pages_found: 1 });

  let crawled = 0;

  while (!abort.cancelled && crawled < MAX_PAGES) {
    const item = dequeueUrl(crawlId);
    if (!item) break;

    const result = await fetchOne(item, crawl, crawlId);
    crawled++;

    const stats = urlQueueStats(crawlId);
    const done  = stats.find(s => s.status === 'done')?.count  || 0;
    const pend  = stats.find(s => s.status === 'pending')?.count || 0;
    const found = done + pend + crawled;

    updateCrawl(crawlId, { pages_done: crawled, pages_found: found });
    onProgress?.({ type: 'progress', crawled, found, latest: result });

    if (abort.cancelled) break;
    await sleep(DELAY_MS);
  }

  if (!abort.cancelled) {
    updateCrawl(crawlId, { status: 'done', finished_at: new Date().toISOString() });
    addLog(crawlId, `Crawl finished — ${crawled} pages crawled`);
    onProgress?.({ type: 'status', status: 'done', crawled });
  }

  activeCrawls.delete(crawlId);
}

export function stopCrawl(crawlId) {
  const ctrl = activeCrawls.get(crawlId);
  if (ctrl) {
    ctrl.cancelled = true;
    activeCrawls.delete(crawlId);
    updateCrawl(crawlId, { status: 'stopped', finished_at: new Date().toISOString() });
    addLog(crawlId, 'Crawl stopped by user');
  }
}

// ── Internal ──────────────────────────────────────────────

async function fetchOne(item, crawl, crawlId) {
  const { url, depth } = item;

  // robots.txt check
  const allowed = await checkRobots(url);
  if (!allowed) {
    markUrlFailed(crawlId, url);
    addLog(crawlId, `Blocked by robots.txt: ${url}`, 'warn');
    return { url, ok: false, reason: 'robots' };
  }

  await respectRateLimit(url);

  let res, body, statusCode, contentType, title, size;
  try {
    const ctrl = new AbortController();
    setTimeout(() => ctrl.abort(), 15000);
    res = await fetch(url, {
      headers: { 'User-Agent': USER_AGENT, 'Accept': 'text/html,*/*' },
      signal: ctrl.signal,
      redirect: 'follow',
    });
    statusCode   = res.status;
    contentType  = res.headers.get('content-type') || '';
    body         = await res.text();
    size         = Buffer.byteLength(body, 'utf8');
    title        = extractTitle(body);
  } catch (err) {
    markUrlFailed(crawlId, url);
    addLog(crawlId, `Fetch error: ${url} — ${err.message}`, 'error');
    return { url, ok: false, reason: err.message };
  }

  // Store a truncated snapshot (first 100kb)
  const snapshot = body.length > 102400 ? body.slice(0, 102400) : body;

  savePage({ crawlId, url, title, statusCode, contentType, size, snapshot });
  markUrlDone(crawlId, url);
  addLog(crawlId, `[${statusCode}] ${title || url}`);

  // Discover links
  if (contentType.includes('text/html') && depth < crawl.depth) {
    const links = extractLinks(body, url);
    let queued = 0;
    for (const link of links) {
      if (crawl.same_domain && !sameDomain(link, crawl.seed_url)) continue;
      if (!hasSeenUrl(crawlId, link)) {
        enqueueUrl(crawlId, link, depth + 1, url);
        queued++;
      }
    }
    if (queued) addLog(crawlId, `  → ${queued} new links from ${url}`);
  }

  return { url, ok: true, statusCode, title, size };
}

async function checkRobots(url) {
  try {
    const origin = new URL(url).origin;
    if (!robotsCache.has(origin)) {
      const res = await fetch(`${origin}/robots.txt`, {
        headers: { 'User-Agent': USER_AGENT },
        signal: AbortSignal.timeout(5000),
      }).catch(() => null);
      const text = res?.ok ? await res.text() : '';
      robotsCache.set(origin, robotsParser(`${origin}/robots.txt`, text));
    }
    return robotsCache.get(origin).isAllowed(url, 'Seadz') !== false;
  } catch { return true; }
}

async function respectRateLimit(url) {
  const domain = new URL(url).hostname;
  const last   = domainTimers.get(domain) || 0;
  const wait   = Math.max(0, DELAY_MS - (Date.now() - last));
  if (wait > 0) await sleep(wait);
  domainTimers.set(domain, Date.now());
}

function extractLinks(html, base) {
  const links = new Set();
  const re = /(?:href)=["']([^"'#][^"']*?)["']/gi;
  let m;
  while ((m = re.exec(html)) !== null) {
    try {
      const r = new URL(m[1], base);
      if (r.protocol !== 'http:' && r.protocol !== 'https:') continue;
      r.hash = '';
      const ext = r.pathname.split('.').pop().toLowerCase();
      if (['jpg','jpeg','png','gif','webp','svg','ico','css','js','pdf','zip','mp4','mp3','woff','woff2','ttf'].includes(ext)) continue;
      links.add(r.toString());
    } catch {}
  }
  return [...links];
}

function extractTitle(html) {
  const m = html.match(/<title[^>]*>([^<]{1,200})<\/title>/i);
  return m ? m[1].trim() : null;
}

function sameDomain(url, base) {
  try { return new URL(url).hostname === new URL(base).hostname; } catch { return false; }
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }
