// db.js — all database access
import Database from 'better-sqlite3';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DATA_DIR = process.env.SEADZ_DATA || path.join(__dirname, '../data');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

const db = new Database(path.join(DATA_DIR, 'seadz.db'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
  CREATE TABLE IF NOT EXISTS crawls (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT NOT NULL,
    seed_url    TEXT NOT NULL,
    depth       INTEGER NOT NULL DEFAULT 2,
    same_domain INTEGER NOT NULL DEFAULT 1,
    status      TEXT NOT NULL DEFAULT 'idle',
    created_at  TEXT NOT NULL DEFAULT (datetime('now')),
    started_at  TEXT,
    finished_at TEXT,
    pages_found INTEGER NOT NULL DEFAULT 0,
    pages_done  INTEGER NOT NULL DEFAULT 0
  );

  CREATE TABLE IF NOT EXISTS urls (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    crawl_id   INTEGER NOT NULL REFERENCES crawls(id) ON DELETE CASCADE,
    url        TEXT NOT NULL,
    status     TEXT NOT NULL DEFAULT 'pending',
    depth      INTEGER NOT NULL DEFAULT 0,
    parent_url TEXT,
    added_at   TEXT NOT NULL DEFAULT (datetime('now')),
    crawled_at TEXT,
    UNIQUE(crawl_id, url)
  );

  CREATE TABLE IF NOT EXISTS pages (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    crawl_id     INTEGER NOT NULL REFERENCES crawls(id) ON DELETE CASCADE,
    url          TEXT NOT NULL,
    title        TEXT,
    status_code  INTEGER,
    content_type TEXT,
    size         INTEGER DEFAULT 0,
    snapshot     TEXT,
    crawled_at   TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS logs (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    crawl_id   INTEGER REFERENCES crawls(id) ON DELETE CASCADE,
    level      TEXT NOT NULL DEFAULT 'info',
    message    TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE INDEX IF NOT EXISTS idx_urls_crawl_status ON urls(crawl_id, status);
  CREATE INDEX IF NOT EXISTS idx_pages_crawl       ON pages(crawl_id);
  CREATE INDEX IF NOT EXISTS idx_pages_url         ON pages(url);
  CREATE INDEX IF NOT EXISTS idx_logs_crawl        ON logs(crawl_id);
`);

export default db;

// ── Crawls ────────────────────────────────────────────────
export function getCrawls() {
  return db.prepare(`SELECT * FROM crawls ORDER BY created_at DESC`).all();
}

export function getCrawl(id) {
  return db.prepare(`SELECT * FROM crawls WHERE id = ?`).get(id);
}

export function createCrawl({ name, seed_url, depth = 2, same_domain = 1 }) {
  const r = db.prepare(`
    INSERT INTO crawls (name, seed_url, depth, same_domain)
    VALUES (?, ?, ?, ?)
  `).run(name, seed_url, depth, same_domain ? 1 : 0);
  return getCrawl(r.lastInsertRowid);
}

export function updateCrawl(id, fields) {
  const keys = Object.keys(fields);
  const set = keys.map(k => `${k} = ?`).join(', ');
  db.prepare(`UPDATE crawls SET ${set} WHERE id = ?`).run(...Object.values(fields), id);
}

export function deleteCrawl(id) {
  db.prepare(`DELETE FROM crawls WHERE id = ?`).run(id);
}

// ── URL queue ─────────────────────────────────────────────
export function enqueueUrl(crawlId, url, depth = 0, parentUrl = null) {
  try {
    db.prepare(`
      INSERT OR IGNORE INTO urls (crawl_id, url, depth, parent_url)
      VALUES (?, ?, ?, ?)
    `).run(crawlId, url, depth, parentUrl);
    return true;
  } catch { return false; }
}

export function dequeueUrl(crawlId) {
  const row = db.prepare(`
    SELECT * FROM urls WHERE crawl_id = ? AND status = 'pending' ORDER BY id ASC LIMIT 1
  `).get(crawlId);
  if (!row) return null;
  db.prepare(`UPDATE urls SET status = 'crawling' WHERE id = ?`).run(row.id);
  return row;
}

export function markUrlDone(crawlId, url) {
  db.prepare(`UPDATE urls SET status = 'done', crawled_at = datetime('now') WHERE crawl_id = ? AND url = ?`).run(crawlId, url);
}

export function markUrlFailed(crawlId, url) {
  db.prepare(`UPDATE urls SET status = 'failed', crawled_at = datetime('now') WHERE crawl_id = ? AND url = ?`).run(crawlId, url);
}

export function hasSeenUrl(crawlId, url) {
  return !!db.prepare(`SELECT 1 FROM urls WHERE crawl_id = ? AND url = ?`).get(crawlId, url);
}

export function urlQueueStats(crawlId) {
  return db.prepare(`
    SELECT status, COUNT(*) as count FROM urls WHERE crawl_id = ? GROUP BY status
  `).all(crawlId);
}

// ── Pages ─────────────────────────────────────────────────
export function savePage({ crawlId, url, title, statusCode, contentType, size, snapshot }) {
  db.prepare(`
    INSERT INTO pages (crawl_id, url, title, status_code, content_type, size, snapshot)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `).run(crawlId, url, title || null, statusCode || null, contentType || null, size || 0, snapshot || null);
}

export function getPages({ crawlId, search, limit = 200, offset = 0 } = {}) {
  let where = crawlId ? `WHERE p.crawl_id = ${crawlId}` : '';
  if (search) {
    const s = search.replace(/'/g, "''");
    const clause = `(p.title LIKE '%${s}%' OR p.url LIKE '%${s}%')`;
    where = where ? `${where} AND ${clause}` : `WHERE ${clause}`;
  }
  return db.prepare(`
    SELECT p.*, c.name as crawl_name
    FROM pages p JOIN crawls c ON p.crawl_id = c.id
    ${where}
    ORDER BY p.crawled_at DESC
    LIMIT ? OFFSET ?
  `).all(limit, offset);
}

export function getPageCount({ crawlId, search } = {}) {
  let where = crawlId ? `WHERE crawl_id = ${crawlId}` : '';
  if (search) {
    const s = search.replace(/'/g, "''");
    const clause = `(title LIKE '%${s}%' OR url LIKE '%${s}%')`;
    where = where ? `${where} AND ${clause}` : `WHERE ${clause}`;
  }
  return db.prepare(`SELECT COUNT(*) as n FROM pages ${where}`).get().n;
}

export function getPage(id) {
  return db.prepare(`SELECT * FROM pages WHERE id = ?`).get(id);
}

// ── Logs ──────────────────────────────────────────────────
export function addLog(crawlId, message, level = 'info') {
  db.prepare(`INSERT INTO logs (crawl_id, level, message) VALUES (?, ?, ?)`).run(crawlId, level, message);
}

export function getLogs(crawlId, limit = 100) {
  return db.prepare(`
    SELECT * FROM logs WHERE crawl_id = ? ORDER BY id DESC LIMIT ?
  `).all(crawlId, limit).reverse();
}

// ── Stats ─────────────────────────────────────────────────
export function globalStats() {
  return {
    totalCrawls:  db.prepare(`SELECT COUNT(*) as n FROM crawls`).get().n,
    totalPages:   db.prepare(`SELECT COUNT(*) as n FROM pages`).get().n,
    totalSize:    db.prepare(`SELECT COALESCE(SUM(size),0) as n FROM pages`).get().n,
    activeCrawls: db.prepare(`SELECT COUNT(*) as n FROM crawls WHERE status = 'running'`).get().n,
  };
}
